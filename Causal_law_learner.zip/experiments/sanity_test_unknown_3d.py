from world.unknown_physics_3d import UnknownPhysicsWorld3D
from world.data_generator_3d import generate_observations_3d
from agent.observer_3d import Observer3D
from agent.hypothesis_generator_3d import HypothesisGenerator3D
from agent.causal_tester_3d import CausalTester3D

world = UnknownPhysicsWorld3D()
data = generate_observations_3d(world)

observer = Observer3D(**data)
hypotheses = HypothesisGenerator3D(observer).generate()

tester = CausalTester3D(
    world=world,
    data_generator=generate_observations_3d
)

print("\nUNKNOWN 3D WORLD — CAUSAL TEST RESULTS")
print(f"(Hidden regime: {world.regime})\n")

for h in hypotheses:
    score = tester.test_invariance(
        h,
        intervention_accels=[
            (1.0, 0.0, 0.0),
            (0.0, 2.0, 0.0),
            (0.0, 0.0, 3.0),
            (1.0, 2.0, 3.0),
        ]
    )
    print(f"{h['name']} → invariance score: {score:.4f}")
