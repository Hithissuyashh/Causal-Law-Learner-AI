import pandas as pd
from agent.observer_3d import Observer3D
from agent.hypothesis_generator_3d import HypothesisGenerator3D
from agent.causal_tester_3d import CausalTester3D
from agent.causal_decision import decide_causal_status
from world.physics_world_3d import PhysicsWorld3D
from world.data_generator_3d import generate_observations_3d

# Load real dataset
df = pd.read_csv("real_motion.csv")

data = {
    "t": df["t"].values,
    "x": df["x"].values,
    "y": df["y"].values,
    "z": df["z"].values if "z" in df else df["y"].values*0
}

observer = Observer3D(**data)
hypotheses = HypothesisGenerator3D(observer).generate()

# Dummy world only for intervention mechanics
world = PhysicsWorld3D()
tester = CausalTester3D(world, generate_observations_3d)

scores = {}
for h in hypotheses:
    scores[h["name"]] = tester.test_invariance(
        h,
        intervention_accels=[
            (1,0,0),
            (0,2,0),
            (0,0,3),
            (1,2,3)
        ]
    )

status, laws = decide_causal_status(scores)

print("\nREAL DATA CAUSAL ANALYSIS")
print("Status:", status)
print("Scores:", scores)
print("Accepted laws:", laws)
print("Rejected laws:", [h["name"] for h in hypotheses if h["name"] not in laws])