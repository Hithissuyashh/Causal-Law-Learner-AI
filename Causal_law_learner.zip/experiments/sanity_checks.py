from world.physics_world import PhysicsWorld
from world.data_generator import generate_observations
from agent.observer import Observer
from agent.hypothesis_generator import HypothesisGenerator
from agent.causal_tester import CausalTester
from agent.law_consolidator import LawConsolidator
from interface.query_engine import QueryEngine

world = PhysicsWorld(x0=0, v0=1, a=2.0, noise=0.02)

t, x = generate_observations(world)

print("First 5 observations:")
for i in range(5):
    print(f"t={t[i]:.2f}, x={x[i]:.3f}")

observer = Observer(t, x)
summary = observer.summary()

print("\nObserver summary:")
for k, v in summary.items():
    print(f"{k}: {v:.4f}")

hyp_gen = HypothesisGenerator(observer)
hypotheses = hyp_gen.generate()

print("\nGenerated hypotheses:")
for h in hypotheses:
    print("-", h["name"])

tester = CausalTester(
    world=PhysicsWorld(x0=0, v0=1, a=2.0, noise=0.02),
    data_generator=lambda w: generate_observations(w)
)

print("\nCausal invariance test results:")

for h in hypotheses:
    var = tester.test_invariance(h, intervention_values=[0.5, 1.0, 2.0, 3.0])
    print(f"{h['name']} → invariance variance: {var:.4f}")

scores = []
for h in hypotheses:
    score = tester.test_invariance(h, intervention_values=[0.5, 1.0, 2.0, 3.0])
    scores.append(score)

consolidator = LawConsolidator(invariance_threshold=2.0)
laws = consolidator.consolidate(hypotheses, scores)

print("\nLearned causal laws:")
for law in laws:
    print("-", law["name"])

engine = QueryEngine(observer, laws)

print("\nAI Explanation:")
print(engine.explain_law())

print("\nFuture prediction (t = 12.0):")
print("Predicted x:", engine.predict_future(12.0))

print("\nWhat-if analysis (increase causal mechanism):")
print(engine.what_if(delta_cause=1.0))


engine = QueryEngine(observer, laws)

print("\nAI Explanation:")
print(engine.explain_law())

print("\nFuture prediction (t = 12.0):")
print("Predicted x:", engine.predict_future(12.0))

print("\nWhat-if analysis (increase causal mechanism):")
print(engine.what_if(delta_cause=1.0))
