from world.physics_world_3d import PhysicsWorld3D
from world.data_generator_3d import generate_observations_3d
from agent.observer_3d import Observer3D
from agent.hypothesis_generator_3d import HypothesisGenerator3D
from agent.causal_tester_3d import CausalTester3D

# Create hidden 3D world
world = PhysicsWorld3D(
    r0=(0, 0, 0),
    v0=(1, 0.5, -0.2),
    a=(1.0, 2.0, 3.0),
    noise=0.02
)

# Generate observations
data = generate_observations_3d(world)

# Observe
observer = Observer3D(**data)

# Generate hypotheses
hyp_gen = HypothesisGenerator3D(observer)
hypotheses = hyp_gen.generate()

# Test causality
tester = CausalTester3D(
    world=world,
    data_generator=generate_observations_3d
)

print("\n3D Causal Invariance Test Results:")
for h in hypotheses:
    score = tester.test_invariance(
        h,
        intervention_accels=[
         (1.0, 0.0, 0.0),
         (0.0, 2.0, 0.0),
         (0.0, 0.0, 3.0),
         (1.0, 2.0, 3.0),
        ]
    )
    print(f"{h['name']} → invariance score: {score:.4f}")
