from world.physics_world_3d_coupled import PhysicsWorld3DCoupled
from world.data_generator_3d import generate_observations_3d
from agent.observer_3d import Observer3D
from agent.hypothesis_generator_3d import HypothesisGenerator3D
from agent.causal_tester_3d import CausalTester3D

world = PhysicsWorld3DCoupled(
    r0=(1, 0, 0),
    v0=(1, 0.5, -0.2),
    base_a=(1.0, 2.0, 3.0),
    coupling=0.3,
    noise=0.02
)

data = generate_observations_3d(world)
observer = Observer3D(**data)

hypotheses = HypothesisGenerator3D(observer).generate()

tester = CausalTester3D(
    world=world,
    data_generator=generate_observations_3d
)

print("\n3D Coupled Causal Invariance Test Results:")

for h in hypotheses:
    score = tester.test_invariance(
        h,
        intervention_accels=[
            (1.0, 0.0, 0.0),
            (0.0, 2.0, 0.0),
            (0.0, 0.0, 3.0),
            (1.0, 2.0, 3.0),
        ]
    )
    print(f"{h['name']} → invariance score: {score:.4f}")
