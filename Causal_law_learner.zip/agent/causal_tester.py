import numpy as np
from agent.observer import Observer

class CausalTester:
    """
    Causal tester for 1D systems.
    Tests invariance of candidate mechanisms under intervention.
    """

    def __init__(self, world, data_generator):
        self.world = world
        self.data_generator = data_generator

    def test_invariance(self, hypothesis, intervention_values):
        """
        Measure how stable a hypothesis is across interventions.
        Lower variance => stronger causal candidate.
        """
        invariant_means = []

        for val in intervention_values:
            # Enforce correct intervention type
            if not np.isscalar(val):
                raise ValueError("1D intervention must be a scalar")

            # Intervene on the world
            self.world.intervene_acceleration(val)

            # Observe outcome
            t, x = self.data_generator(self.world)
            observer = Observer(t, x)

            # Select test signal
            if hypothesis["test_signal"] == "dx":
                signal = observer.first_difference()
            elif hypothesis["test_signal"] == "d2x":
                signal = observer.second_difference()
            else:
                raise ValueError("Unknown test signal")

            invariant_means.append(np.mean(signal))

        # Variance of means = invariance score
        return float(np.var(invariant_means))

    def run_tests(self, hypotheses, intervention_values):
        """
        Run causal tests for all hypotheses.
        """
        results = {}
        for h in hypotheses:
            results[h["name"]] = self.test_invariance(h, intervention_values)
        return results
