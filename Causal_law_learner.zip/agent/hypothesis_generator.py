class HypothesisGenerator:
    """
    Generates candidate causal hypotheses from observations.
    """

    def __init__(self, observer):
        self.observer = observer

    def generate(self):
        """
        Return hypotheses as explicit claims.
        """
        return [
            {
                "name": "Position depends linearly on time",
                "type": "first_order",
                "test_signal": "dx"
            },
            {
                "name": "Rate of change is constant",
                "type": "first_order_invariant",
                "test_signal": "dx"
            },
            {
                "name": "Second-order change is invariant",
                "type": "second_order_invariant",
                "test_signal": "d2x"
            }
        ]

