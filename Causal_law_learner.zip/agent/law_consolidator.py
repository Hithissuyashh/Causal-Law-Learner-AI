class LawConsolidator:
    """
    Consolidates surviving causal hypotheses into learned laws.
    """

    def __init__(self, invariance_threshold=2.0):
        self.threshold = invariance_threshold
        self.learned_laws = []

    def consolidate(self, hypotheses, invariance_scores):
        """
        Accept hypotheses that survive causal testing.
        """
        for h, score in zip(hypotheses, invariance_scores):
            if score < self.threshold:
                self.learned_laws.append(h)

        return self.learned_laws
