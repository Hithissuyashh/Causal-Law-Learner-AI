class HypothesisGenerator3D:
    def __init__(self, observer):
        self.observer = observer

    def generate(self):
        return [
            {
                "name": "Independent second-order invariance per axis",
                "type": "axiswise_second_order"
            },
            {
                "name": "Joint vector second-order invariance",
                "type": "vector_second_order"
            }
        ]
