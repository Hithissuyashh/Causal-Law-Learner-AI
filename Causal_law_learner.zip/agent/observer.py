import numpy as np

class Observer:
    """
    Builds internal representations from raw observations.
    """

    def __init__(self, t, x):
        self.t = t
        self.x = x

    def first_difference(self):
        """
        Approximate first derivative dx/dt
        """
        dt = np.diff(self.t)
        dx = np.diff(self.x)
        return dx / dt

    def second_difference(self):
        """
        Approximate second derivative d2x/dt2
        """
        v = self.first_difference()
        dt = np.diff(self.t[:-1])
        dv = np.diff(v)
        return dv / dt

    def summary(self):
        """
        Basic statistics for reasoning.
        """
        return {
            "x_mean": np.mean(self.x),
            "x_var": np.var(self.x),
            "dx_mean": np.mean(self.first_difference()),
            "dx_var": np.var(self.first_difference()),
            "d2x_mean": np.mean(self.second_difference()),
            "d2x_var": np.var(self.second_difference()),
        }
