import numpy as np
from agent.observer_3d import Observer3D

class CausalTester3D:
    """
    Causal tester for 3D physical systems.
    Ensures axis-wise invariance of second-order mechanisms.
    """

    def __init__(self, world, data_generator):
        self.world = world
        self.data_generator = data_generator

    def test_invariance(self, hypothesis, intervention_accels):
        """
        Test causal invariance across vector-valued interventions.
        """
        axis_means = []

        for accel in intervention_accels:
            # Enforce correct intervention type
            accel = np.array(accel)
            if accel.shape != (3,):
                raise ValueError("3D intervention must be a vector of length 3")

            # Intervene on world
            self.world.intervene_acceleration(accel)

            # Observe system
            data = self.data_generator(self.world)
            observer = Observer3D(**data)

            # Compute second-order signal
            d2 = observer.second_difference()      # shape: (n-2, 3)
            axis_means.append(np.mean(d2, axis=0)) # shape: (3,)

        axis_means = np.array(axis_means)          # shape: (k, 3)

        # Axis-wise invariance (each axis must be stable)
        axis_variance = np.var(axis_means, axis=0)

        # Final invariance score (scalar)
        return float(np.mean(axis_variance))
