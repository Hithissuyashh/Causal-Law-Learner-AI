import numpy as np

class Observer3D:
    def __init__(self, t, x, y, z):
        self.t = t
        self.pos = np.stack([x, y, z], axis=1)

    def first_difference(self):
        dt = np.diff(self.t)
        dp = np.diff(self.pos, axis=0)
        return dp / dt[:, None]

    def second_difference(self):
        v = self.first_difference()
        dt = np.diff(self.t[:-1])
        dv = np.diff(v, axis=0)
        return dv / dt[:, None]

    def summary(self):
        return {
            "d2_mean": np.mean(self.second_difference(), axis=0),
            "d2_var": np.var(self.second_difference(), axis=0)
        }
