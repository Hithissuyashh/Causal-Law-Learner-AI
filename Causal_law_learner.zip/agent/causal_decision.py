def decide_causal_status(scores, threshold=2.0):
    passed = [k for k, v in scores.items() if v < threshold]

    if len(passed) == 1:
        return "law_found", passed
    elif len(passed) > 1:
        return "causal_equivalence", passed
    else:
        return "no_law_identified", []
