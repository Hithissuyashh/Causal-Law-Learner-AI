from fastapi import FastAPI, UploadFile, File, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles

import pandas as pd
import io

# -----------------------------
# 1D PIPELINE IMPORTS
# -----------------------------
from world.physics_world import PhysicsWorld
from world.data_generator import generate_observations
from agent.observer import Observer
from agent.hypothesis_generator import HypothesisGenerator
from agent.causal_tester import CausalTester
from agent.law_consolidator import LawConsolidator
from interface.query_engine import QueryEngine

# -----------------------------
# APP INIT
# -----------------------------
app = FastAPI(
    title="Causal Physics Law Learner",
    description="Learns causal physical laws from time-series data",
    version="1.0"
)

templates = Jinja2Templates(directory="ui/templates")
app.mount("/static", StaticFiles(directory="ui/static"), name="static")

STATE = {}  # Simple in-memory state (v1)

# -----------------------------
# UI HOME
# -----------------------------
@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

# =========================================================
# 1D CAUSAL DISCOVERY
# =========================================================
@app.post("/discover")
async def discover(file: UploadFile = File(...)):
    try:
        df = pd.read_csv(io.BytesIO(await file.read()))
    except Exception as e:
        return {"status": "refused", "reason": f"CSV parsing failed: {e}"}

    if not {"t", "x"}.issubset(df.columns):
        return {"status": "refused", "reason": "CSV must contain columns: t, x"}

    observer = Observer(df["t"].values, df["x"].values)
    hypotheses = HypothesisGenerator(observer).generate()

    world = PhysicsWorld(x0=0, v0=1, a=2.0, noise=0.02)
    tester = CausalTester(world, generate_observations)

    scores = [
        tester.test_invariance(h, [0.5, 1.0, 2.0, 3.0])
        for h in hypotheses
    ]

    laws = LawConsolidator(2.0).consolidate(hypotheses, scores)

    if not laws:
        return {"status": "refused", "reason": "No invariant causal law found"}

    STATE["observer"] = observer
    STATE["laws"] = laws

    return {
        "status": "success",
        "learned_laws": [l["name"] for l in laws],
        "invariance_scores": dict(zip([h["name"] for h in hypotheses], scores))
    }

# -----------------------------
# 1D QUERY
# -----------------------------
@app.get("/query")
def query(type: str, t_future: float = None, delta_cause: float = None):
    if "observer" not in STATE or "laws" not in STATE:
        return {"status": "refused", "reason": "No causal law discovered yet"}

    engine = QueryEngine(STATE["observer"], STATE["laws"])

    if type == "explain":
        return {"status": "success", "explanation": engine.explain_law()}

    if type == "predict":
        if t_future is None:
            return {"status": "refused", "reason": "t_future required"}
        return {"status": "success", "prediction": engine.predict_future(t_future)}

    if type == "what_if":
        if delta_cause is None:
            return {"status": "refused", "reason": "delta_cause required"}
        return {"status": "success", "result": engine.what_if(delta_cause)}

    return {"status": "refused", "reason": "Unknown query type"}

# =========================================================
# 3D CAUSAL ANALYSIS (UI + REAL DATA)
# =========================================================
@app.post("/analyze")
async def analyze(file: UploadFile = File(...)):
    from agent.observer_3d import Observer3D
    from agent.hypothesis_generator_3d import HypothesisGenerator3D
    from agent.causal_tester_3d import CausalTester3D
    from agent.causal_decision import decide_causal_status
    from world.physics_world_3d import PhysicsWorld3D
    from world.data_generator_3d import generate_observations_3d

    try:
        df = pd.read_csv(io.BytesIO(await file.read()))
    except Exception as e:
        return {"status": "refused", "reason": f"CSV parsing failed: {e}"}

    if not {"t", "x"}.issubset(df.columns):
        return {"status": "refused", "reason": "CSV must contain at least columns: t, x"}

    data = {
        "t": df["t"].values,
        "x": df["x"].values,
        "y": df["y"].values if "y" in df else df["x"].values * 0,
        "z": df["z"].values if "z" in df else df["x"].values * 0,
    }

    observer = Observer3D(**data)
    hypotheses = HypothesisGenerator3D(observer).generate()

    world = PhysicsWorld3D()
    tester = CausalTester3D(world, generate_observations_3d)

    scores = {
        h["name"]: tester.test_invariance(
            h, [(1,0,0), (0,2,0), (0,0,3), (1,2,3)]
        )
        for h in hypotheses
    }

    status, accepted = decide_causal_status(scores)

    return {
        "status": status,
        "scores": scores,
        "accepted_laws": accepted,
        "prediction_allowed": status == "law_found"
    }
