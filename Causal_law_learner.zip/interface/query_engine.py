import numpy as np

class QueryEngine:
    """
    Answers questions using learned causal laws.
    """

    def __init__(self, observer, learned_laws):
        self.observer = observer
        self.learned_laws = learned_laws

    def explain_law(self):
        """
        Human-readable explanation of learned law.
        """
        if any(law["type"] == "second_order_invariant" for law in self.learned_laws):
            return (
                "The system is governed by a stable second-order mechanism.\n"
                "Changes in the outcome are driven by a constant second-order cause.\n"
                "This mechanism remains invariant under intervention."
            )
        return "No stable causal law identified."

    def predict_future(self, t_future):
        """
        Predict future outcome using the learned causal mechanism.
        """
        # Estimate second-order term from observations
        a_est = np.mean(self.observer.second_difference())

        # Use last known values
        t_last = self.observer.t[-1]
        x_last = self.observer.x[-1]
        v_est = np.mean(self.observer.first_difference())

        dt = t_future - t_last
        x_future = x_last + v_est * dt + 0.5 * a_est * dt**2

        return x_future

    def what_if(self, delta_cause):
        """
        Counterfactual: what if the causal mechanism changes?
        """
        a_est = np.mean(self.observer.second_difference())
        new_a = a_est + delta_cause

        return {
            "original_second_order": a_est,
            "new_second_order": new_a,
            "effect": "Outcome curvature will increase" if delta_cause > 0 else "Outcome curvature will decrease"
        }
