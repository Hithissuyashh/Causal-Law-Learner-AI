import numpy as np

def generate_observations(world, t_start=0.0, t_end=10.0, num_points=100):
    """
    Generate raw observations (t, x).
    No derivatives, no labels, no hints.
    """
    t_values = np.linspace(t_start, t_end, num_points)
    x_values = [world.position(t) for t in t_values]

    return np.array(t_values), np.array(x_values)
