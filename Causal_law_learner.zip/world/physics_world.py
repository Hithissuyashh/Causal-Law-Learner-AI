import numpy as np

class PhysicsWorld:
    """
    Hidden physical world governed by constant acceleration.
    The agent NEVER sees the parameters directly.
    """

    def __init__(self, x0=0.0, v0=0.0, a=1.0, noise=0.01):
        self.x0 = x0
        self.v0 = v0
        self.a = a
        self.noise = noise

    def position(self, t):
        """
        True position at time t with observational noise.
        """
        true_x = self.x0 + self.v0 * t + 0.5 * self.a * t**2
        noise = np.random.normal(0, self.noise)
        return true_x + noise

    def intervene_acceleration(self, new_a):
        """
        Intervention: change the acceleration.
        """
        self.a = new_a
