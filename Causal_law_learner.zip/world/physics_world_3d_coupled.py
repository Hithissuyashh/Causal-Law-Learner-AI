import numpy as np

class PhysicsWorld3DCoupled:
    """
    True causal coupling:
    y-acceleration depends on x(t), not x0.
    """

    def __init__(self, r0=(0,0,0), v0=(0,0,0),
                 base_a=(1,2,3), coupling=0.2, noise=0.01):
        self.r0 = np.array(r0, dtype=float)
        self.v0 = np.array(v0, dtype=float)
        self.base_a = np.array(base_a, dtype=float)
        self.coupling = coupling
        self.noise = noise

    def position(self, t):
        # x(t) from uncoupled motion
        x_t = self.r0[0] + self.v0[0]*t + 0.5*self.base_a[0]*(t**2)

        ax = self.base_a[0]
        ay = self.base_a[1] + self.coupling * x_t   # REAL coupling
        az = self.base_a[2]

        a = np.array([ax, ay, az])
        r = self.r0 + self.v0*t + 0.5*a*(t**2)

        noise = np.random.normal(0, self.noise, size=3)
        return r + noise

    def intervene_acceleration(self, new_base_a):
        self.base_a = np.array(new_base_a, dtype=float)
