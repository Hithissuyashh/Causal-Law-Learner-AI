import numpy as np

class PhysicsWorld3D:
    """
    Hidden 3D physical world with constant acceleration.
    """

    def __init__(self, r0=(0,0,0), v0=(0,0,0), a=(1,2,3), noise=0.01):
        self.r0 = np.array(r0)
        self.v0 = np.array(v0)
        self.a = np.array(a)
        self.noise = noise

    def position(self, t):
        true_r = self.r0 + self.v0*t + 0.5*self.a*(t**2)
        noise = np.random.normal(0, self.noise, size=3)
        return true_r + noise

    def intervene_acceleration(self, new_a):
        self.a = np.array(new_a)
