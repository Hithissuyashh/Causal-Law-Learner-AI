import numpy as np

def generate_observations_3d(world, t_start=0, t_end=10, n=100):
    t_vals = np.linspace(t_start, t_end, n)
    positions = np.array([world.position(t) for t in t_vals])

    return {
        "t": t_vals,
        "x": positions[:,0],
        "y": positions[:,1],
        "z": positions[:,2],
    }
