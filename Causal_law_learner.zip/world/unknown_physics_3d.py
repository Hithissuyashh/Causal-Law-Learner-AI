import numpy as np
import random

class UnknownPhysicsWorld3D:
    """
    Hidden 3D physics with randomly chosen causal structure.
    """

    def __init__(self, noise=0.02):
        self.noise = noise
        self.regime = random.choice(["constant", "coupled", "time_varying"])

        self.r0 = np.random.uniform(-1, 1, size=3)
        self.v0 = np.random.uniform(-1, 1, size=3)
        self.base_a = np.random.uniform(0.5, 3.0, size=3)

    def position(self, t):
        if self.regime == "constant":
            a = self.base_a

        elif self.regime == "coupled":
            x_t = self.r0[0] + self.v0[0]*t + 0.5*self.base_a[0]*t**2
            a = np.array([
                self.base_a[0],
                self.base_a[1] + 0.3 * x_t,
                self.base_a[2]
            ])

        elif self.regime == "time_varying":
            a = self.base_a + 0.5 * np.sin(t)

        r = self.r0 + self.v0*t + 0.5*a*t**2
        noise = np.random.normal(0, self.noise, size=3)
        return r + noise

    def intervene_acceleration(self, new_a):
        self.base_a = np.array(new_a)
